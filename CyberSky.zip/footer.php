<footer>
    <div class="container">
        <div class="col-100">
           
                <p>
                    Cybersky
                </p>
          
        </div>
    </div>
</footer>

</body>

</html>